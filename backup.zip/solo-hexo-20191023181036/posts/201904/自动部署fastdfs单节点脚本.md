title: 自动部署fastdfs单节点脚本
date: '2019-04-26 16:45:02'
updated: '2019-05-12 10:15:45'
tags: [fastdfs]
permalink: /articles/2019/04/26/1556268302662.html
---
```
yum -y install make cmake gcc gcc-c++ wget net-tools >> /dev/null
sleep 10

#安装yum源
banben=`cat /etc/redhat-release | grep -o [0-9]|head -n 1`
[ $banben -eq 6 ] && wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-6.repo || wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo

#2.安装libfastcommon
mkdir /root/src -p
cd /root/src
wget http://122.114.164.162:10004/libfastcommon-master.zip
rpm -qa |grep unzip >>/dev/null     #判断是否安装unzip，最小化系统没有安装unzip
[ `echo $?` = 0 ] || yum -y install unzip 
unzip libfastcommon-master.zip
cd libfastcommon-master
./make.sh && ./make.sh install
ln -s /usr/lib64/libfastcommon.so /usr/local/lib/libfastcommon.so
ln -s /usr/lib64/libfastcommon.so /usr/lib/libfastcommon.so
ln -s /usr/lib64/libfdfsclient.so /usr/local/lib/libfdfsclient.so
ln -s /usr/lib64/libfdfsclient.so /usr/lib/libfdfsclient.so


#3.安装tracker
yum -y install gettext gettext-devel libXft libXft-devel libXpm libXpm-devel autoconf libxtst-devel zlib-devel libpng-devel  glib-devel >> /dev/null
sleep 20
cd /root/src
wget http://122.114.164.162:10004/FastDFS_v5.04.tar.gz
tar zxvf FastDFS_v5.04.tar.gz
cd FastDFS
./make.sh && ./make.sh install
cd /etc/fdfs/
cp tracker.conf.sample tracker.conf
sed -i "s/base_path=\/home\/yuqing\/fastdfs/base_path=\/home\/fastdfs\/tracker/g" tracker.conf
mkdir -p /home/fastdfs/tracker >>/dev/null
iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport 22122 -j ACCEPT
fdfs_trackerd /etc/fdfs/tracker.conf restart
echo "/usr/bin/fdfs_trackerd /etc/fdfs/tracker.conf restart" >> /etc/rc.local

#4.安装stroge
ip=`ip a | grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|tr -d "addr:"| awk -F"/" '{print $1}'`
cd /etc/fdfs
if [ $banben = "6" ];then
	cp -a storage.conf.sample storage.conf
	sed -i "s/base_path=\/home\/yuqing\/fastdfs/base_path=\/home\/fastdfs\/storage/g" storage.conf
	sed -i "s/tracker_server=192.168.209.121:22122/tracker_server=$ip:22122/g" storage.conf
	sed -i "s/store_path0=\/home\/yuqing\/fastdfs/store_path0=\/home\/fastdfs\/storage/g" storage.conf
	cd /etc/fdfs
	cp /root/src/FastDFS/conf/client.conf .
	cp /root/src/FastDFS/conf/mime.types .
	cp /root/src/FastDFS/conf/storage_ids.conf .
	cp /root/src/FastDFS/conf/http.conf .
	mkdir /home/fastdfs/storage
	fdfs_storaged /etc/fdfs/storage.conf restart
	echo "/usr/bin/fdfs_storaged /etc/fdfs/storage.conf restart" >> /etc/rc.local
	iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport 23000 -j ACCEPT
	cd /etc/fdfs
	sed -i "s/base_path=\/home\/yuqing\/fastdfs/base_path=\/home\/fastdfs\/tracker/g" client.conf
	sed -i "s/tracker_server=192.168.0.197:22122/tracker_server=$ip:22122/g" client.conf
	ln -s /home/fastdfs/storage/data /home/fastdfs/storage/data/M00
else
	cp -a storage.conf.sample storage.conf
        sed -i "s/base_path=\/home\/yuqing\/fastdfs/base_path=\/home\/fastdfs\/storage/g" storage.conf
        sed -i "s/tracker_server=192.168.209.121:22122/tracker_server=$ip:22122/g" storage.conf
        sed -i "s/store_path0=\/home\/yuqing\/fastdfs/store_path0=\/home\/fastdfs\/storage/g" storage.conf
        cd /etc/fdfs
        cp /root/src/FastDFS/conf/client.conf .
        cp /root/src/FastDFS/conf/mime.types .
        cp /root/src/FastDFS/conf/storage_ids.conf .
        cp /root/src/FastDFS/conf/http.conf .
        mkdir /home/fastdfs/storage
        fdfs_storaged /etc/fdfs/storage.conf restart
        echo "/usr/bin/fdfs_storaged /etc/fdfs/storage.conf restart" >> /etc/rc.local
        iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport 23000 -j ACCEPT
        cd /etc/fdfs
        sed -i "s/base_path=\/home\/yuqing\/fastdfs/base_path=\/home\/fastdfs\/tracker/g" client.conf
        sed -i "s/tracker_server=192.168.0.197:22122/tracker_server=$ip:22122/g" client.conf
        ln -s /home/fastdfs/storage/data /home/fastdfs/storage/data/M00
fi
sleep 10

#5.安装nginx
cd /root/src
yum -y install libtool pcre pcre-devel zlib zlib-devel openssl openssl-devel
wget http://122.114.164.162:10004/nginx-1.4.7.tar.gz
wget http://122.114.164.162:10004/fastdfs-nginx-module_v1.16.tar.gz
wget http://122.114.164.162:10004/pcre-8.36.tar.gz
tar zxvf nginx-1.4.7.tar.gz
tar zxvf fastdfs-nginx-module_v1.16.tar.gz
tar zxvf pcre-8.36.tar.gz
sed -i "s/CORE_INCS=\"\$CORE_INCS\ \/usr\/local\/include\/fastdfs\ \/usr\/local\/include\/fastcommon\/\"/CORE_INCS=\"\$CORE_INCS\ \/usr\/include\/fastdfs\ \/usr\/include\/fastcommon\/\"/g" fastdfs-nginx-module/src/config
cd /root/src/nginx-1.4.7
./configure --prefix=/usr/local/nginx --add-module=/root/src/fastdfs-nginx-module/src --with-pcre=/root/src/pcre-8.36
sleep 5
make && make install
sleep 10
cp /root/src/fastdfs-nginx-module/src/mod_fastdfs.conf /etc/fdfs/
cd /etc/fdfs
sed -i "s/tracker_server=tracker:22122/tracker_server=$ip:22122/g" mod_fastdfs.conf
sed -i "s/base_path=\/tmp/base_path=\/home\/fastdfs\/storage/g" mod_fastdfs.conf
sed -i "s/url_have_group_name\ =\ false/url_have_group_name\ =\ true/g" mod_fastdfs.conf 
sed -i "s/store_path0=\/home\/yuqing\/fastdfs/store_path0=\/home\/fastdfs\/storage/g" mod_fastdfs.conf 
cat <<EOF > /usr/local/nginx/conf/nginx.conf
worker_processes  1;
events {
    worker_connections  1024;
}
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    keepalive_timeout  65;
    server {
        listen       8888;
        server_name  localhost;
        location / {
            root   html;
            index  index.html index.htm;
        }
        location ~ /group[1-3]/M00 {
            root /home/fastdfs/storage/data;
            ngx_fastdfs_module;
        }
        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }
    }
}
EOF
cd /usr/local/nginx/sbin
./nginx
echo "/usr/local/nginx/sbin/nginx" >> /etc/rc.d/rc.local
iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport 8888 -j ACCEPT
```