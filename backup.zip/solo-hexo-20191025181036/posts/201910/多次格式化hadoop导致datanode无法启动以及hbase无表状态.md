title: 多次格式化hadoop导致datanode无法启动以及hbase无表状态。
date: '2019-10-23 10:16:39'
updated: '2019-10-23 10:16:39'
tags: [hadoop]
permalink: /articles/2019/10/23/1571796999506.html
---
### 一、**多次格式化namenode导致无法启动datanode节点，报错如下：**
![1.png](https://img.hacpai.com/file/2019/10/1-b8c9bbee.png)
解决办法：
①停止hadoop集群。
```
/home/hadoop/hadoop-2.8.4/sbin/stop-all.sh
```
②删除core-site.xml 和hdfs-site.xml文件中配置的文件夹（注意：整个集群机器都要操作，主节点是删除namenode的目录；从节点是删除datanode的目录。）
```
rm -rf /home/hadoop/hadoop-2.8.4/name/*

rm -rf /home/hadoop/hadoop-2.8.4/data/*

rm -rf /home/hadoop/hadoop-2.8.4/tmp/*
```
![2.png](https://img.hacpai.com/file/2019/10/2-00e12b3a.png)
---
![3.png](https://img.hacpai.com/file/2019/10/3-6c93895a.png)
③ 再次格式化。
主节点执行：hadoop namenode -format
④重启hadoop集群。
### **二、多次格式化hadoop导致hbase无法创建表问题。**
①停止hbase集群。
②删除原来hbase配置文件下zookeeper的配置目录。
`rm -rf /home/hadoop/zookeeper-3.4.12/data/*`
③重新格式化opentsdb并创建表。
`env COMPRESSION=none HBASE_HOME=/home/hadoop/hbase-1.2.6/ /usr/share/opentsdb/tools/create_table.sh`
④重新启动hbase集群。

