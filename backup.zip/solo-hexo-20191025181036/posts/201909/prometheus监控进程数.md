title: prometheus监控进程数
date: '2019-09-17 11:43:45'
updated: '2019-09-17 11:43:45'
tags: [待分类]
permalink: /articles/2019/09/17/1568691825436.html
---
    由于我们常用的node_exporter并不能覆盖所有监控项，这里我们使用Process-exporter 对进程进行监控。
## 一、客户端安装process-exporter

```
wget https://github.com/ncabatoff/process-exporter/releases/download/v0.4.0/process-exporter-0.4.0.linux-amd64.tar.gz
tar -xvf  process-exporter-0.4.0.linux-amd64.tar.gz -C /usr/local/
```
创建配置文件
======

可用的模板变量：  
{{.Comm}} 包含原始可执行文件的basename，/proc//stat 中的换句话说，2nd 字段  
{{.ExeBase}} 包含可执行文件的basename  
{{.ExeFull}} 包含可执行文件的完全限定路径  
{{.Matches}} 映射包含应用命令行tlb所产生的所有匹配项


定义进程名监控
-------

Process-exporter 可以进程名字匹配进程，获取进程信息。匹配规则由name对应的模板变量决定，以下表示监控进程名字为nginx 与 zombie 的进程状态。
```
process_names:
  - name: "{{.Matches}}"
    cmdline:
    - 'nginx'

  - name: "{{.Matches}}"
    cmdline:
    - 'vsftpd'
```
启动服务，可以查看帮助。
![1.jpg](https://img.hacpai.com/file/2019/09/1-324e92eb.jpg)
**启动服务,并放到后台运行。**
`nohup ./process-exporter -config.path etc/process-name.yaml &`
**查看数据，可以看到关于nginx进程的多个指标，以下框内为进程状态对应的进程数。**
![2.jpg](https://img.hacpai.com/file/2019/09/2-7d0eec2a.jpg)
## **二、将该Process_export加入服务端**
```
vim /etc/prometheus/prometheus.yml
- job_name: 'test'
    static_configs:
    - targets: ['10.34.44.169:9256']
```
**重启prometheus服务**
`systemctl restart prometheus`
****登陆prometheus服务端进行查看
![3.jpg](https://img.hacpai.com/file/2019/09/3-bb8d5a6a.jpg)
## 三、在服务端看到数据，接下来进行报警。
```
cat linux-process-alter.rules

groups:
- name: processAlert
  rules:
  - alert: host-nginx-alter
    expr: (namedprocess_namegroup_states{state="Sleeping",groupname="map[:nginx]"} offset 1m) == 0
    for: 5m
    labels:
      severity: page
    annotations:
      summary: "Instance {{ $labels.instance }} nginx is down"
      description: "{{ $labels.instance }} nginx is down (current value: {{ $value }})"
```
以上规则意思是当nginx进程sleeping=0时就触发警报。
**将我们写的规则放到web界面进行测试。**
![image.png](https://img.hacpai.com/file/2019/09/image-3963db17.png)
此状态说明nginx是正常的，并么有挂掉（等于0是么有数据的）

我们可以看下nginx的实际状态。
![image.png](https://img.hacpai.com/file/2019/09/image-70950dda.png)

以上就是监控进程，如果有很多相同的监控项，比如有多个nginx，此处我们可以添加多个条件进行报警。









