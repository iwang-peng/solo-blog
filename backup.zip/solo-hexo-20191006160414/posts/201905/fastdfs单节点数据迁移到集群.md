title: fastdfs单节点数据迁移到集群
date: '2019-05-12 13:31:01'
updated: '2019-05-12 13:31:01'
tags: [fastdfs]
permalink: /articles/2019/05/12/1557639061333.html
---
场景介绍：
前期公司业务量较小，使用了fastdfs单节点做图片服务器，后期在做集群服务使用了fastdfs集群，所以需要把数据从单机点迁移到集群里面。
搭建fastdfs集群请看上篇文章。
解决步骤：
#### ①将原来单节点的tracker的data目录整体复制到新的集群tracker的data目录下备份新集群tracker下的data目录
cd /home/fastdfs/tracker && tar zcvf data-tracker.tar.gz date/
#将原来的单节点tracker下的data复制过来
略
#修改storage_servers_new.dat配置文件
cd data && vim storage_servers_new.dat
#修改以下两项
![1.png](https://img.hacpai.com/file/2019/05/1-dd9dbfa4.png)
---
![2.png](https://img.hacpai.com/file/2019/05/2-ab905aa9.png)
#### ②将storage目录下的data文件夹之际拷贝过去，覆盖新的文件系统中的storage中的data目录，进行如下的修改（使用ll -a查看隐藏文件）：
vim .data_init_flag
![3.png](https://img.hacpai.com/file/2019/05/3-5cf3b0d7.png)
#将上述文件中的旧ip改为新地址的ip即可。
③重新启动tracker、storage
/usr/bin/fdfs_trackerd /etc/fdfs/tracker.conf restart
/usr/bin/fdfs_storaged /etc/fdfs/storage.conf restart
④若迁移前后ip地址和端口不发生变化，一一对应，可直接将data目录拷贝过去，不需要修改任何信息。


