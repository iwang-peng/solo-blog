title: openldap双主搭建
date: '2019-04-26 16:55:40'
updated: '2019-04-30 14:43:02'
tags: [openldap]
permalink: /articles/2019/04/26/1556268940013.html
---
![](https://img.hacpai.com/bing/20180308.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

---

1.  系统：centos7.5
2.  软件版本：openldap-2.4.4
3.  配置文件:/etc/openldap/sldap.conf
4.  # 主机名 IP(配置好主机名,分别在两台主机 hosts文件中添加对端的IP域名解析)
5.  HOSTNAME:ldap1.test.com IP:192.168.30.77
6.  HOSTNAME:ldap2.test.com IP:192.168.30.79
7.  HOSTNAME:test IP:192.168.30.80

初始化环境
-----

> 所有主机执行

1.配置防火墙

1.  firewall-cmd--zone=public--add-port=389/tcp--permanent
2.  firewall-cmd--zone=public--add-port=636/tcp--permanent
3.  firewall-cmd--reload

2.关闭, 禁用selinux

1.  setenforce0
2.  sed-i's/^SELINUX=.*/SELINUX=disabled/'/etc/selinux/config

3.配置软件安装源

1.  rm-f/etc/yum.repos.d/*
2.  curl -so /etc/yum.repos.d/epel-7.repo http://mirrors.aliyun.com/repo/epel-7.repo
3.  curl -so /etc/yum.repos.d/Centos-7.repo http://mirrors.aliyun.com/repo/Centos-7.repo
4.  sed -i '/aliyuncs.com/d' /etc/yum.repos.d/Centos-7.repo /etc/yum.repos.d/epel-7.repo

4.配置时间同步

1.  yum-y install ntpdate
2.  /usr/sbin/ntpdate ntp6.aliyun.com;hwclock-w
3.  echo-e"*/30 * * * * /usr/sbin/ntpdate ntp6.aliyun.com >/dev/null 2>&1 && /usr/sbin/hwclock -w">/tmp/crontab
4.  crontab/tmp/crontab

### 安装 OpenLdap

> 所有主机执行

1.安装OpenLdap与相关软件包

1.  yum install-y openldap openldap-devel openldap-servers openldap-clients openldap-devel compat-openldap

### 创建CA证书

> ldap1.test.com 主机执行

1.CA中心生成自身私钥

1.  cd/etc/pki/CA
2.  (umask077;openssl genrsa-outprivate/cakey.pem2048)

2.CA签发自身公钥

1.  openssl req-new-x509-keyprivate/cakey.pem-outcacert.pem-days3650\
2.  -subj"/C=CN/ST=HuBei/L=WuHan/O=test/OU=test.com/CN=*.test.com/emailAddress=88888@qq.com"
3.  touch serial index.txt
4.  echo"01">serial

3.查看生成的根证书信息

1.  openssl x509-noout-text-in/etc/pki/CA/cacert.pem

### 创建ldap证书

> ldap1.test.com 主机执行

1.OpenLdap服务端生成证书

1.  mkdir/etc/openldap/ssl
2.  cd/etc/openldap/ssl
3.  (umask077;openssl genrsa-outldapkey.pem1024)

2.OpenLdap服务端向CA申请证书签署请求

> 注意：[CN=*.test.com] 此处与主机名后缀对应

1.  openssl req-new-key ldapkey.pem-outldap.csr-days3650\
2.  -subj"/C=CN/ST=HuBei/L=WuHan/O=test/OU=test.com/CN=*.test.com/emailAddress=88888@qq.com"

3.CA核实并签发证书

1.  openssl ca-in/etc/openldap/ssl/ldap.csr-out/etc/openldap/ssl/ldapcert.pem-days3650

4.设置证书权限

1.  cp/etc/pki/CA/cacert.pem/etc/openldap/ssl/
2.  chown-R ldap.ldap/etc/openldap/ssl/*
3.  chmod -R 0400 /etc/openldap/ssl/*

### 配置 OpenLdap

> ldap1.test.com 主机执行

1.复制数据库配置文件

1.  cp/usr/share/openldap-servers/DB_CONFIG.example/var/lib/ldap/DB_CONFIG

2.设置配置文件,数据目录权限

1.  chown-R ldap.ldap/etc/openldap/
2.  chown-R ldap.ldap/var/lib/ldap/

3.启动服务,配置服务跟随系统启动

1.  systemctl start slapd
2.  systemctl enable slapd

4.生成管理员密码

> 管理员密码为 admim

1.  pass=admin
2.  slappasswd-s $pass-n>/etc/openldap/passwd
3.  cat/etc/openldap/passwd
4.  ldap_pass="$(cat /etc/openldap/passwd)"

5.创建slapd 配置文件

1.  cat<<EOF>/etc/openldap/slapd.conf
2.  include/etc/openldap/schema/corba.schema
3.  include/etc/openldap/schema/core.schema
4.  include/etc/openldap/schema/cosine.schema
5.  include/etc/openldap/schema/duaconf.schema
6.  include/etc/openldap/schema/dyngroup.schema
7.  include/etc/openldap/schema/inetorgperson.schema
8.  include/etc/openldap/schema/java.schema
9.  include/etc/openldap/schema/misc.schema
10.  include/etc/openldap/schema/nis.schema
11.  include/etc/openldap/schema/openldap.schema
12.  include/etc/openldap/schema/ppolicy.schema
13.  include/etc/openldap/schema/collective.schema
14.  allow bind_v2
15.  pidfile/var/run/openldap/slapd.pid
16.  argsfile/var/run/openldap/slapd.args
17.  modulepath/usr/lib64/openldap
18.  moduleload ppolicy.la
19.  TLSCACertificateFile/etc/openldap/ssl/cacert.pem
20.  TLSCertificateFile/etc/openldap/ssl/ldapcert.pem
21.  TLSCertificateKeyFile/etc/openldap/ssl/ldapkey.pem
22.  TLSVerifyClientnever
23.  access to attrs=shadowLastChange,userPassword
24.  byselfwrite
25.  by*auth
26.  access to*
27.  by*read
28.  database config
29.  access to*
30.  bydn.exact="gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth"manage
31.  by*none
32.  database monitor
33.  access to*
34.  bydn.exact="gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth"read
35.  bydn.exact="cn=admin,dc=test,dc=com"read
36.  by*none
37.  database hdb
38.  suffix"dc=test,dc=com"
39.  checkpoint102415
40.  rootdn"cn=admin,dc=test,dc=com"
41.  rootpw $ldap_pass
42.  directory/var/lib/ldap
43.  index objectClass eq,pres
44.  index ou,cn,mail,surname,givenname eq,pres,sub
45.  index uidNumber,gidNumber,loginShell eq,pres
46.  index uid,memberUid eq,pres,sub
47.  index nisMapName,nisMapEntry eq,pres,sub
48.  loglevel4095
49.  # 同步ldap2.test.com (如果配置单机版本则无需以下配置)
50.  moduleload syncprov.la
51.  modulepath/usr/lib64/openldap
52.  index entryCSN,entryUUID eq
53.  overlay syncprov
54.  syncprov-checkpoint10010
55.  syncprov-sessionlog100
56.  serverID1
57.  syncrepl rid=001
58.  provider=ldaps://ldap2.test.com
59.  bindmethod=simple
60.  binddn="cn=admin,dc=test,dc=com"
61.  credentials=linux
62.  searchbase="dc=test,dc=com"
63.  schemachecking=on
64.  type=refreshAndPersist
65.  retry="5 5 300 5"
66.  starttls=yes
67.  mirrormode on
68.  EOF

6.配置监听服务

1.  sed-i's/SLAPD_URLS/#SLAPD_URLS/'/etc/sysconfig/slapd
2.  cat<<EOF>>/etc/sysconfig/slapd
3.  # OpenLDAP Ldaps
4.  SLAPD_URLS="ldapi:/// ldap:/// ldaps:///"
5.  SLAPD_LDAP=yes
6.  SLAPD_LDAPI=yes
7.  SLAPD_LDAPS=yes
8.  EOF

7.生成新的配置(依据slapd.conf配置项生成新的配置)

1.  rm-rf/etc/openldap/slapd.d/*
2.  slaptest -f /etc/openldap/slapd.conf -F /etc/openldap/slapd.d/

8.设置目录权限, 重启服务

1.  chown-R ldap.ldap/etc/openldap/slapd.d
2.  chown-R ldap.ldap/var/lib/ldap/
3.  systemctl restart slapd

9.配置日志

1.  cat<<EOF>>/etc/rsyslog.conf
2.  # ldap log
3.  local4.*/var/log/slapd/slapd.log
4.  EOF
5.  systemctl restart rsyslog

### 测试添加用户, 组

> ldap1.test.com 主机执行

1.创建本地测试用户

1.  foruserinldapuser{1..5}feng{1..5};do
2.  useradd $user
3.  echo redhat|passwd--stdin $user
4.  done

2.使用工具生成ldif文件

1.  # 安装工具
2.  yum install-y migrationtools
3.  # 替换域信息
4.  sed-i"71,74 s/padl/test/g"/usr/share/migrationtools/migrate_common.ph
5.  sed-i"71,74 s/com/com/g"/usr/share/migrationtools/migrate_common.ph
6.  sed-i's/EXTENDED_SCHEMA = 0/EXTENDED_SCHEMA = 1/'/usr/share/migrationtools/migrate_common.ph
7.  # 生成基础架构,根据密码文件生成用户信息,根据组文件生成组信息
8.  /usr/share/migrationtools/migrate_base.pl>~/base.ldif
9.  /usr/share/migrationtools/migrate_passwd.pl/etc/passwd>~/passwd.ldif
10.  /usr/share/migrationtools/migrate_group.pl/etc/group>~/group.ldif

3.导入数据导入至OpenLdap目录树

1.  ldapadd-x-w $pass-D"cn=admin,dc=test,dc=com"-f~/base.ldif
2.  ldapadd-x-w $pass-D"cn=admin,dc=test,dc=com"-f~/passwd.ldif
3.  ldapadd-x-w $pass-D"cn=admin,dc=test,dc=com"-f~/group.ldif

### 测试验证

> ldap1.test.com 主机执行

1.搜索导入的用户

1.  ldapsearch-x cn=ldapuser1-b dc=test,dc=com
2.  foruserinldapuser{1..5}feng{1..5};do
3.  echo"---------- id $user ----------"
4.  ldapsearch-x cn=$user-b dc=test,dc=com
5.  sleep1
6.  echo
7.  done

2.验证 OpenLdap 证书是否正常

1.  openssl verify-CAfile/etc/openldap/ssl/cacert.pem/etc/openldap/ssl/ldapcert.pem

3.验证套接字是否能通过CA验证

1.  openssl s_client-connect ldap1.test.com:636-showcerts-state-CAfile/etc/openldap/