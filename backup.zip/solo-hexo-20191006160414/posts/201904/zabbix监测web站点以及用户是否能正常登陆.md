title: zabbix监测web站点以及用户是否能正常登陆
date: '2019-04-26 16:32:13'
updated: '2019-04-26 16:32:13'
tags: [zabbix]
permalink: /articles/2019/04/26/1556267533725.html
---
![](https://img.hacpai.com/bing/20190103.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**一、创建web站点和web站点是否可以登录**
-------------------------

（1）获取需要监控的站点的后台接口

[![attachments-2019-04-SqnDBIwS5ca451562737c.png](http://bbs.haocang.com/image/show/attachments-2019-04-SqnDBIwS5ca451562737c.png)](http://bbs.haocang.com/image/show/attachments-2019-04-SqnDBIwS5ca451562737c.png)

（2）登陆zabbix的web界面，进行web站点监控

[![attachments-2019-04-SqoBclBS5ca4515e646d8.png](http://bbs.haocang.com/image/show/attachments-2019-04-SqoBclBS5ca4515e646d8.png)](http://bbs.haocang.com/image/show/attachments-2019-04-SqoBclBS5ca4515e646d8.png)

（3）创建web站点监控

[![attachments-2019-04-0A2gHEfu5ca451662cb00.png](http://bbs.haocang.com/image/show/attachments-2019-04-0A2gHEfu5ca451662cb00.png)](http://bbs.haocang.com/image/show/attachments-2019-04-0A2gHEfu5ca451662cb00.png)

（4）监控具体步骤

①场景

[![attachments-2019-04-EbPMnML55ca451700f85a.png](http://bbs.haocang.com/image/show/attachments-2019-04-EbPMnML55ca451700f85a.png)](http://bbs.haocang.com/image/show/attachments-2019-04-EbPMnML55ca451700f85a.png)

②步骤---->添加{监控网站状态}

[![attachments-2019-04-h5TmlyQq5ca4519407264.png](http://bbs.haocang.com/image/show/attachments-2019-04-h5TmlyQq5ca4519407264.png)](http://bbs.haocang.com/image/show/attachments-2019-04-h5TmlyQq5ca4519407264.png)

③添加  {再监测用户是否可以登录web站点}

[![attachments-2019-04-vTfU7FxM5ca451a5d26b6.png](http://bbs.haocang.com/image/show/attachments-2019-04-vTfU7FxM5ca451a5d26b6.png)](http://bbs.haocang.com/image/show/attachments-2019-04-vTfU7FxM5ca451a5d26b6.png)

④查看刚才我们创建的web监测

[![attachments-2019-04-JHFkGEiz5ca451ad565fe.png](http://bbs.haocang.com/image/show/attachments-2019-04-JHFkGEiz5ca451ad565fe.png)](http://bbs.haocang.com/image/show/attachments-2019-04-JHFkGEiz5ca451ad565fe.png)

二、触发警报

（1）配置---->主机----->触发器--->创建触发器

[![attachments-2019-04-Gb1DbDTO5ca4520d5efb7.png](http://bbs.haocang.com/image/show/attachments-2019-04-Gb1DbDTO5ca4520d5efb7.png)](http://bbs.haocang.com/image/show/attachments-2019-04-Gb1DbDTO5ca4520d5efb7.png)

（2）名称（自己命名触发器名字）---->构建表达式（出现下面页面）

监控项：我这里指的是监控的web站点，返回码只要不是200就触发报警

[![attachments-2019-04-uH6g7keN5ca45246e7038.png](http://bbs.haocang.com/image/show/attachments-2019-04-uH6g7keN5ca45246e7038.png)](http://bbs.haocang.com/image/show/attachments-2019-04-uH6g7keN5ca45246e7038.png)

[![attachments-2019-04-rgRpPBdz5ca4527308f21.png](http://bbs.haocang.com/image/show/attachments-2019-04-rgRpPBdz5ca4527308f21.png)](http://bbs.haocang.com/image/show/attachments-2019-04-rgRpPBdz5ca4527308f21.png)

[![attachments-2019-04-4yzCsIgP5ca4527e44d29.png](http://bbs.haocang.com/image/show/attachments-2019-04-4yzCsIgP5ca4527e44d29.png)](http://bbs.haocang.com/image/show/attachments-2019-04-4yzCsIgP5ca4527e44d29.png)

（3）查看我们创建好的触发器

[![attachments-2019-04-uqIxkXpM5ca45288c9bec.png](http://bbs.haocang.com/image/show/attachments-2019-04-uqIxkXpM5ca45288c9bec.png)](http://bbs.haocang.com/image/show/attachments-2019-04-uqIxkXpM5ca45288c9bec.png)

同理，使用这种方式监控web站点是否可以登录，根据返回的状态码，只要不是200就触发报警