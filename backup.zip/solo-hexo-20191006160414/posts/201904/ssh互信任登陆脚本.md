title: ssh互信任登陆脚本
date: '2019-04-26 16:47:34'
updated: '2019-04-28 09:39:53'
tags: [ssh]
permalink: /articles/2019/04/26/1556268454172.html
---
1.  1.检测本地是否有秘钥文件
2.  1.1没有则生成秘钥文件
3.  2.检测是否安装expect命令
4.  2.1没有则安装expect
5.  3.循环主机列表
6.  3.1将本机公钥发送到主机列表中的所有主机
7.  3.2检测列表中的主机是否有秘钥文件
8.  3.2.1没有则生成秘钥文件
9.  3.2.2检测本机authorized_keys文件中是否包含远程主机公钥
10.  3.2.2.1没有则将远程主机公钥添加到本机authorized_keys文件
11.  4.循环主机列表
12.  4.1将本机authorized_keys文件同步到远程所有主机
13.  4.2远程主机创建ssh配置文件(ssh免输入yes)
14.  5.循环主机列表(测试连通性)
---


#### 创建 ssh-key.sh 文件

1.  cat>ssh-key.sh<<'EOF'
2.  #!/bin/bash
3.  # 检测脚本输入的变量是否是两个
4.  if[$# != 2 ] ; then
5.  echo"USAGE: $0 '192.168.0.2 192.168.0.3 102.168.0.4' password"
6.  exit1;
7.  fi
8.  # 本机生成密钥
9.  [-f~/.ssh/id_rsa]||ssh-keygen-t rsa-P''-f~/.ssh/id_rsa
10.  # 安装 expect
11.  echo'Install expect .... '
12.  [-f/usr/bin/expect]||yum-y install expect>/dev/null
13.  # 将本机公钥发送到远程主机
14.  SSH_KEY(){
15.  /usr/bin/expect-c"
16.  set timeout 10
17.  spawn ssh-copy-id -o StrictHostKeyChecking=no -i /root/.ssh/id_rsa.pub root@$1
18.  expect {
19.  password: {
20.  send $2\r;
21.  interact;
22.  }
23.  }
24.  "
25.  }
26.  forIPin$1;do
27.  SSH_KEY $IP $2
28.  ssh $IP"[ -f ~/.ssh/id_rsa ] || ssh-keygen -t rsa -P '' -f ~/.ssh/id_rsa"
29.  RemoteKey="$(ssh $IP 'cat ~/.ssh/id_rsa.pub')"
30.  if[!"$(grep "$RemoteKey" ~/.ssh/authorized_keys)"];then
31.  echo"$RemoteKey">>~/.ssh/authorized_keys
32.  fi
33.  done
34.  forIPin$1;do
35.  scp~/.ssh/authorized_keys $IP:~/.ssh/authorized_keys
36.  ssh $IP"
37.  echo 'Host *' > ~/.ssh/config
38.  echo 'UserKnownHostsFile /dev/null' >> ~/.ssh/config
39.  echo 'StrictHostKeyChecking no' >> ~/.ssh/config
40.  echo 'LogLevel quiet' >> ~/.ssh/config
41.  echo 'Port 22' >> ~/.ssh/config
42.  "
43.  done
44.  # test
45.  forIPin$1;do
46.  echoLocal:$IP
47.  ssh-T-oStrictHostKeyChecking=no$IP"
48.  for IP in $1; do
49.  ssh -T \$IP hostname -I
50.  done
51.  "
52.  done
53.  EOF
---

#### 使用方法

1.  chmod+x ssh-key.sh
2.  ./ssh-key.sh'192.168.0.2 192.168.0.3 192.168.0.4'RootPass