title: 基于mysql_export实现granafa的数据展示
date: '2019-09-18 15:32:02'
updated: '2019-09-18 15:32:02'
tags: [mysql_export]
permalink: /articles/2019/09/18/1568791922423.html
---
## 一、环境：
centos7.6
mysql_exprot0.12
mysql5.7
## 二、安装
**①下载mysql_export**
```wget https://github.com/prometheus/mysqld_exporter/releases/download/v0.12.1/mysqld_exporter-0.12.1.linux-amd64.tar.gz```

**②在被监控端mysql服务器上创建账号用于mysql exporter收集使用**
```
GRANT REPLICATION CLIENT, PROCESS ON  *.*  to 'exporter'@'%' identified by '123456';
GRANT SELECT ON performance_schema.* TO 'exporter'@'%';
flush privileges;
```
**③解压mysql_export**
`ttar zxvf mysqld_exporter-0.12.1.linux-amd64.tar.gz -C /usr/local/`
④设置配置文件
```
cd /usr/local/mysqld_exporter-0.12.1.linux-amd64/
vim my.cnf
[client]
user=exporter
password=123456
```
⑤启动mysql_export
`nohup ./mysqld_exporter --config.my-cnf=./my.cnf &`
⑥将mysql_export加入到prometheus服务端（注意格式）.
```
vim /etc/prometheus/prometheus.yml
- job_name: 'shfj_mysql'
    static_configs:
    - targets: ['10.34.44.182:9104]
```
![1.png](https://img.hacpai.com/file/2019/09/1-b20c36b3.png)

⑦重启prometheus.
`systemctl restart prometheus`
查看该job是否在prometheus服务端正常。
![2.png](https://img.hacpai.com/file/2019/09/2-42139eaa.png)
⑧配置prometheus数据源并导入grafana仪表盘。
![3.png](https://img.hacpai.com/file/2019/09/3-ada02f75.png)
---
![4.png](https://img.hacpai.com/file/2019/09/4-abeb3c42.png)
---
![5.png](https://img.hacpai.com/file/2019/09/5-3e6ddba7.png)
---
![6.png](https://img.hacpai.com/file/2019/09/6-4b7d821b.png)
模板下载地址：链接：https://pan.baidu.com/s/1Ea9g3L1rPriTyXCNdPou5A 
提取码：jnjc 
![7.png](https://img.hacpai.com/file/2019/09/7-6cfd448f.png)



