title: zabbix-3.4搭建并创建监控报警
date: '2019-04-26 16:52:17'
updated: '2019-04-26 16:52:17'
tags: [zabbix]
permalink: /articles/2019/04/26/1556268737599.html
---
环境
--

1.  系统：centos7.5
2.  软件版本：
3.  mysql:5.7
4.  zabbix:3.4.15
5.  内网:
6.  Port:10051
7.  IP:192.168.2.71
8.  外网:
9.  Port:34521
10.  Domain:freefrp.cn
11.  Agent被动模式(默认)
12.  server端主动连接agent
13.  server和agent在同一个网络中
14.  或者将agent10050端口映射到公网
15.  Agent主动模式
16.  agent主动连接server端
17.  server和agent在同一个网络中
18.  或者将server10051端口映射到公网
---

安装
--

### 配置YUM源

1.  mkdir/etc/yum.repos.d/OldRepo
2.  mv/etc/yum.repos.d/*.repo /etc/yum.repos.d/OldRepo/
3.  curl -so /etc/yum.repos.d/epel-7.repo http://mirrors.aliyun.com/repo/epel-7.repo
4.  curl -so /etc/yum.repos.d/Centos-7.repo http://mirrors.aliyun.com/repo/Centos-7.repo
5.  sed -i '/aliyuncs.com/d' /etc/yum.repos.d/Centos-7.repo /etc/yum.repos.d/epel-7.repo

### 配置时间同步

1.  yum install-y ntpdate
2.  ntpdate ntp1.aliyun.com
3.  hwclock-w
4.  echo"*/30 * * * * $(which ntpdate) ntp1.aliyun.com > /dev/null 2>&1 && $(which hwclock) -w">/var/spool/cron/root
5.  chmod600/var/spool/cron/root

### 配置防火墙,Selinux

> 80:zabbix-web 3306:mysql 10050:zabbix-agent 10051:zabbix-server

1.  firewall-cmd--zone=public--add-port=80/tcp--permanent
2.  firewall-cmd--zone=public--add-port=3360/tcp--permanent
3.  firewall-cmd--zone=public--add-port=10050/tcp--permanent
4.  firewall-cmd--zone=public--add-port=10051/tcp--permanent
5.  firewall-cmd--reload
6.  setenforce0
7.  sed-i's/SELINUX=enforcing/SELINUX=disabled/g'/etc/selinux/config
---

### 安装mysql

> 安装mysql-5.7

1.  # 配置安装源
2.  yum install-y https://dev.mysql.com/get/mysql80-community-release-el7-1.noarch.rpm
3.  yum repolist all|grep mysql# 查看所有 mysql 子存储库
4.  yum install-y yum-utils# 安装 yum 配置工具管理 YUM 源
5.  yum-config-manager--disable mysql80-community# 禁用 mysql80 子存储库
6.  yum-config-manager--enable mysql57-community
7.  yum repolist enabled|grep mysql# 查看已启用的 mysql 子存储库
8.  # 安装mysql
9.  yum install-y mysql-community-server
10.  # 启动 mysql 服务,跟随系统启动
11.  systemctl start mysqld
12.  systemctl status mysqld
13.  systemctl enable mysqld
14.  # 修改数据库密码,创建zabbix 用户并授权(设置mysql本地登录root密码为12WWW.ttt 创建zabbix用户密码为12WWW.ttt)
15.  NewPass='12WWW.ttt'
16.  DefPass=$(grep'temporary password'/var/log/mysqld.log|awk'{print $NF}')
17.  # 修改root本地密码,创建zabbix用户,数据库并授权
18.  mysql-uroot-p$DefPass--connect-expired-password<<-EOSQL
19.  alter user'root'@'localhost'identifiedby'${NewPass}';
20.  create database zabbix charactersetutf8 collate utf8_bin;
21.  grant all privileges on zabbix.*to'zabbix'@'%'identifiedby'${NewPass}';
22.  flush privileges;
23.  EOSQL
---

### 安装zabbix服务端

1.  # 安装 zabbix软件 存储库 [http://repo.zabbix.com/zabbix/3.4/rhel/7/x86_64/]
2.  rpm-ivh http://repo.zabbix.com/zabbix/3.4/rhel/7/x86_64/zabbix-release-3.4-2.el7.noarch.rpm
3.  # 安装Zabbix部署包
4.  yum makecache
5.  yum install-y zabbix-server-mysql zabbix-web-mysql

配置
--

### 导入zabbix数据库

1.  zcat/usr/share/doc/zabbix-server-mysql-3.4.15/create.sql.gz|mysql-uzabbix-p$NewPass zabbix

### 创建zabix_server配置文件

1.  cat<<EOF>/etc/zabbix/zabbix_server.conf
2.  ExternalScripts=/usr/lib/zabbix/externalscripts
3.  SNMPTrapperFile=/var/log/snmptrap/snmptrap.log
4.  AlertScriptsPath=/usr/lib/zabbix/alertscripts
5.  LogFile=/var/log/zabbix/zabbix_server.log
6.  PidFile=/var/run/zabbix/zabbix_server.pid
7.  SocketDir=/var/run/zabbix
8.  LogFileSize=0
9.  DBHost=192.168.2.71
10.  DBName=zabbix
11.  DBUser=zabbix
12.  DBPassword=$NewPass
13.  Timeout=30
14.  LogSlowQueries=3000
15.  EOF

### 启动ZabbixServer进程,跟随系统启动

1.  systemctl start zabbix-server
2.  systemctl status zabbix-server
3.  systemctl enable zabbix-server
---

### 配置Apache

1.  # 更改 php, apache 时区
2.  sed-i's#;date.timezone =.*#date.timezone = "Asia/Shanghai"#'/etc/php.ini
3.  sed-i'20a\ php_value date.timezone Asia/ShangHai'/etc/httpd/conf.d/zabbix.conf
4.  # 启动Apache进程,跟随系统启动
5.  systemctl start httpd
6.  systemctl status httpd
7.  systemctl enable httpd

### 配置数据库连接

1.  浏览器打开http://192.168.2.71/zabbix 点击 Next steup
2.  # 配置数据库连接

[![配置数据库连接](https://oscimg.oschina.net/oscnet/f624a6dcd6c04ce04cfd5d5507ac956dfee.jpg)](https://oscimg.oschina.net/oscnet/f624a6dcd6c04ce04cfd5d5507ac956dfee.jpg)

1.  # 配置端口

[![配置端口](https://oscimg.oschina.net/oscnet/97987b97685c45153f4ecd0eb81f76a266a.jpg)](https://oscimg.oschina.net/oscnet/97987b97685c45153f4ecd0eb81f76a266a.jpg)

1.  # 登录 默认管理员账号 Admin 密码 zabbix

[![登录](https://oscimg.oschina.net/oscnet/5dc43429b0af6c8082fd18b0cfe7ebbcf2a.jpg)](https://oscimg.oschina.net/oscnet/5dc43429b0af6c8082fd18b0cfe7ebbcf2a.jpg)
---

创建agent主动模式模板
-------------

### Linux主动模式模板

1.  # 点击 配置 → 模板 → Template OS Linux

[![linux_template](https://oscimg.oschina.net/oscnet/496fb134947cd2b99f3fd0ce864158ed119.jpg)](https://oscimg.oschina.net/oscnet/496fb134947cd2b99f3fd0ce864158ed119.jpg)

1.  # 更改模板名称为 Active OS Linux 点击底部全克隆 然后点击底部添加

[![linux_template_active](https://oscimg.oschina.net/oscnet/4e5e4eef52b6a1240e04e2a94a7af8ce676.jpg)](https://oscimg.oschina.net/oscnet/4e5e4eef52b6a1240e04e2a94a7af8ce676.jpg)  
[![linux_template_active](https://oscimg.oschina.net/oscnet/bd3347d725c4905fce5bdd7c21c30e4cea5.jpg)](https://oscimg.oschina.net/oscnet/bd3347d725c4905fce5bdd7c21c30e4cea5.jpg)

1.  # 点击 配置 → 模板 → Active OS Linux 链接的模板 → 取消链接并清理

[![linux_template_unlink](https://oscimg.oschina.net/oscnet/6b9d227b5e842102c931e62d207f6f9f705.jpg)](https://oscimg.oschina.net/oscnet/6b9d227b5e842102c931e62d207f6f9f705.jpg)

1.  # 点击应用集 选择 Template App Zabbix Agent: Zabbix agent 禁用

[![linux_template_active_ietms0](https://oscimg.oschina.net/oscnet/67a965cd43c9fc50d3b75cbac50ecb9f495.jpg)](https://oscimg.oschina.net/oscnet/67a965cd43c9fc50d3b75cbac50ecb9f495.jpg)

1.  # 点击 监控项 勾选所有监控项 点击底部 批量更新

[![linux_template_active_ietms1](https://oscimg.oschina.net/oscnet/15d63aa56a0c76747dd4ad24548ecd131b4.jpg)](https://oscimg.oschina.net/oscnet/15d63aa56a0c76747dd4ad24548ecd131b4.jpg)  
[![linux_template_active_ietms2](https://oscimg.oschina.net/oscnet/36a08afcd9320328fb0f1caf92f75b9ad67.jpg)](https://oscimg.oschina.net/oscnet/36a08afcd9320328fb0f1caf92f75b9ad67.jpg)

1.  # 勾选 类型 选择 zabbix客户端(主动式) 点击底部 更新

[![linux_template_active_ietms3](https://oscimg.oschina.net/oscnet/36122d0d7367d09aed04abe58e3804049ab.jpg)](https://oscimg.oschina.net/oscnet/36122d0d7367d09aed04abe58e3804049ab.jpg)  
[![linux_template_active_ietms4](https://oscimg.oschina.net/oscnet/305b071a620cdb4081cde58774b91e19dd0.jpg)](https://oscimg.oschina.net/oscnet/305b071a620cdb4081cde58774b91e19dd0.jpg)

1.  # 点击 自动发现 分别点击 名称 将类型改为 zabbix客户端(主动式)

[![linux_template_items5](https://oscimg.oschina.net/oscnet/45491bacbb2e10a096a02b1dbe6cad3ddea.jpg)](https://oscimg.oschina.net/oscnet/45491bacbb2e10a096a02b1dbe6cad3ddea.jpg)

[![linux_template_items6](https://oscimg.oschina.net/oscnet/a2748676fa5cee97501ddaecc5ca234439d.jpg)](https://oscimg.oschina.net/oscnet/a2748676fa5cee97501ddaecc5ca234439d.jpg)

1.  # 点击 自动发现 分别点击 监控原型 中的每一项名称 将类型更改为 zabbix客户端(主动式)

[![linux_template_items7](https://oscimg.oschina.net/oscnet/229c6be80c8504d5a10147840de9431bb0b.jpg)](https://oscimg.oschina.net/oscnet/229c6be80c8504d5a10147840de9431bb0b.jpg)

[![linux_template_items7](https://oscimg.oschina.net/oscnet/2c5bf0b910599ad857d814d1ad2634cf5d9.jpg)](https://oscimg.oschina.net/oscnet/2c5bf0b910599ad857d814d1ad2634cf5d9.jpg)
---

> Windows主动模式模板 选择Template OS Windows 克隆 配置过程与linux相同

客户端安装配置

> IP: 192.168.2.72 agent主动模式

### Linux安装zabbix-agent

1.  # 安装源码库配置部署包
2.  rpm-ivh http://repo.zabbix.com/zabbix/3.4/rhel/7/x86_64/zabbix-release-3.4-2.el7.noarch.rpm
3.  # 被监控端 安装Zabbix Agent
4.  yum install-y zabbix-agent

### 配置 agent

1.  # 创建配置文件 主动模式
2.  cat<<EOF>/etc/zabbix/zabbix_agentd.conf
3.  PidFile=/var/run/zabbix/zabbix_agentd.pid
4.  LogFile=/var/log/zabbix/zabbix_agentd.log
5.  LogFileSize=0
6.  StartAgents=0
7.  ServerActive=freefrp.cn:34521
8.  Hostname=$(hostname-I)
9.  RefreshActiveChecks=60
10.  Include=/etc/zabbix/zabbix_agentd.d/*.conf
11.  EOF
12.  # 启动服务
13.  systemctl start zabbix-agent
14.  systemctl enable zabbix-agent
---

### Windows安装zabbix-agent

> agent下载地址 [https://www.zabbix.com/download_agents](https://www.zabbix.com/download_agents)

1.  下载Windowszabbix_agents https://www.zabbix.com/downloads/3.4.6/zabbix_agents_3.4.6.win.zip
2.  将压缩文件解压到D盘
3.  打开cmd
4.  >D:
5.  >md zabbix
6.  >copy zabbix_agents_3.4.6.win\bin\win64\* zabbix\
7.  >echoLogFile=c:\zabbix_agentd.log>zabbix/zabbix_agentd.win.conf
8.  >echoLogFileSize=0>>zabbix/zabbix_agentd.win.conf
9.  >echoStartAgents=0>>zabbix/zabbix_agentd.win.conf
10.  >echoServerActive=freefrp.cn:34521>>zabbix/zabbix_agentd.win.conf
11.  >echoHostname=192.168.2.104>>zabbix/zabbix_agentd.win.conf
12.  >echoRefreshActiveChecks=60>>zabbix/zabbix_agentd.win.conf
13.  >D:\zabbix\zabbix_agentd.exe-i-c D:\zabbix\zabbix_agentd.win.conf
14.  >D:\zabbix\zabbix_agentd.exe-s-c D:\zabbix\zabbix_agentd.win.conf
15.  # 安装服务
16.  # D:\zabbix\zabbix_agentd.exe -i -c D:\zabbix\zabbix_agentd.win.conf
17.  # 启动服务
18.  # D:\zabbix\zabbix_agentd.exe -s -c D:\zabbix\zabbix_agentd.win.conf
19.  # 卸载服务(停止 zabbix agent 服务)
20.  # D:\zabbix\zabbix_agentd.exe -d -c D:\zabbix\zabbix_agentd.win.conf

zabbix-server 添加主机
------------------

1.  # 配置 → 主机 → 创建主机

[![add-host](https://oscimg.oschina.net/oscnet/9db307606c13d755bd94a11093f8b2eea0f.jpg)](https://oscimg.oschina.net/oscnet/9db307606c13d755bd94a11093f8b2eea0f.jpg)

1.  # 输入配置信息

[![add-host2](https://oscimg.oschina.net/oscnet/3f586ac3a98fee2f0b89f4253d6e5e82ad4.jpg)](https://oscimg.oschina.net/oscnet/3f586ac3a98fee2f0b89f4253d6e5e82ad4.jpg)

1.  # 点击模板 选择 Active OS Linux 点击添加

[![](https://oscimg.oschina.net/oscnet/45113d60478ef820deed99dc0d05cf09eed.jpg)](https://oscimg.oschina.net/oscnet/45113d60478ef820deed99dc0d05cf09eed.jpg)

1.  # 点击主机 滚动条移动到底部 点击添加

[![add-host3](https://oscimg.oschina.net/oscnet/f639f2db09b33aeb1759adb13f3ae0ef1d9.jpg)](https://oscimg.oschina.net/oscnet/f639f2db09b33aeb1759adb13f3ae0ef1d9.jpg)

[![](https://oscimg.oschina.net/oscnet/e2c86d8d7f9a69226a237bc202782474948.jpg)](https://oscimg.oschina.net/oscnet/e2c86d8d7f9a69226a237bc202782474948.jpg)

[![](https://oscimg.oschina.net/oscnet/6c6aa0f34b5acddee78a625ff0d75043d4b.jpg)](https://oscimg.oschina.net/oscnet/6c6aa0f34b5acddee78a625ff0d75043d4b.jpg)

[![](https://oscimg.oschina.net/oscnet/c89d6b3edb2a36f1140bf70fd901a975c35.jpg)](https://oscimg.oschina.net/oscnet/c89d6b3edb2a36f1140bf70fd901a975c35.jpg)

[![](https://oscimg.oschina.net/oscnet/03e9856185acc6ae2e8bbc403bc0fc05ff5.jpg)](https://oscimg.oschina.net/oscnet/03e9856185acc6ae2e8bbc403bc0fc05ff5.jpg)

agent被动模式配置
-----------

1.  # 被动模式
2.  cat<<EOF>/etc/zabbix/zabbix_agentd.conf
3.  PidFile=/var/run/zabbix/zabbix_agentd.pid
4.  LogFile=/var/log/zabbix/zabbix_agentd.log
5.  LogFileSize=0
6.  StartAgents=3
7.  Server=192.168.2.71
8.  ServerActive=192.168.2.71
9.  Hostname=$(hostname-I)
10.  HostMetadataItem=system.uname
11.  EOF
12.  # 创建主机时选择系统默认自带的模板即可