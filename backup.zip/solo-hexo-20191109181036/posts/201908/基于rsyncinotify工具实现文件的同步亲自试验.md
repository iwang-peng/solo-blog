title: 基于rsync+inotify工具实现文件的同步,亲自试验。
date: '2019-08-13 10:03:11'
updated: '2019-08-13 10:07:35'
tags: [rsync, inotify]
permalink: /articles/2019/08/13/1565661791078.html
---
## 一、需求
为了做生产系统的高可用，现将图片服务器实时同步到另一个备用的生产环境。
## 二、环境
centos7.6
## 三、具体说明
| ip | 用途 | 软件|
| --- | --- | --- |
| 10.34.44.117| 图片服务器| rsync客户端、xinetd、inotify|
| 10.34.44.224 |  被同步服务器|  rsync服务端、xinetd|
## 四、具体操作步骤。
首先防火墙、selinux关闭。
### （1）以下步骤在10.34.44.224上执行。
**①安装rsync服务端、xinetd服务**

`yum install -y rsync xinetd`

**②注意：CentOS中是以xinetd来管理Rsync服务的，CentOS7中不存在/etc/xinetd.d/rsync（CentOS6中存在），需自己创建，把下面这段复制进去即可。**

```
# description: The rsync server is a good addition to an ftp server, as it 
#       allows crc checksumming etc.
 service rsync
 {
        disable = no    #由默认的yes改为no，设置开机启动rsync
        flags = IPv6
        socket_type = stream
        wait = no
        user = root
        server = /usr/bin/rsync
        server_args = --daemon
        log_on_failure += USERID
}
```

**③启动xinetd服务**
systemctl start xinetd
systemctl enable xinetd
**④创建/etc/rsyncd.conf文件，并配置同步策略。**
```
uid = root
gid = root
use chroot = no
max connections = 200
timeout = 600
strict modes = yes
hosts allow = 10.34.44.117
port = 873
transfer logging = yes
log format = %h %o %f %l %b
log file = /var/log/rsyncd.log
pid file = /var/run/rsyncd.pid
secrets file = /etc/rsyncd.secrets  #用户认证配置文件，里面保存用户名称和密码，后面会创建这个文件

[fastdfs]
path = /home/fastdfs/   #被同步的服务器的目录
ignore errors = yes	
comment = fastdfs
read only = false
list = false
auth users = root
```
**⑤创建用户认证文件 (多个模块用的是这同一个认证文件)**
echo "root:rsyncpasswd" /etc/rsyncd.secrets
**⑥为了安全起见，设置文件权限，即rsyncd.conf和rsync.pass认证文件都是600权限。**
chmod 600 /etc/rsyncd.conf 
chmod 600 /etc/rsyncd.secrets
### （2）以下步骤在10.34.44.117上操作。
**①安装rsync和xinetd**
`yum install -y rsync xinetd`
**②拷贝10.34.44.224的/etc/xinetd.d/rsync的配置文件到本地。**
scp 10.34.44.224:/etc/xinetd.d/rsync /etc/xinetd.d
**③启动xinetd服务**
systemctl start xinetd
systemctl enable xinetd
**④创建同步的密码文件，这个文件名可以跟服务端的认证文件不一样，但是里面的密码必须一致！用于rsync同步命令中。**
echo "rsyncpasswd" /etc/rsyncd.secrets       #注意：在客户端是只需要写认证密码，不要带认证用户，不然报错。
**⑤初步同步。**
```
rsync -vzrtopg  --delete --progress  --bwlimit=3000 --exclude-from=/home/fastdfs/tracker/data/storage_servers_new.dat --exclude-from=/home/fastdfs/tracker/data/storage_sync_timestamp.dat --exclude-from=/home/fastdfs/storage/data/.data_init_flag --password-file=/etc/rsyncd.secrets /home/fastdfs root@10.34.44.224::fastdfs
```
参数说明：
```
-v, --verbose 详细模式输出

-q, --quiet 精简输出模式
-c, --checksum 打开校验开关，强制对文件传输进行校验
-a, --archive 归档模式，表示以递归方式传输文件，并保持所有文件属性，等于-rlptgoD
-r, --recursive 对子目录以递归模式处理
-R, --relative 使用相对路径信息
-b, --backup 创建备份，也就是对于目的已经存在有同样的文件名时，将老的文件重新命名为~filename。可以使用--suffix选项来指定不同的备份文件前缀。
--backup-dir 将备份文件(如~filename)存放在在目录下。
-suffix=SUFFIX 定义备份文件前缀
-u, --update 仅仅进行更新，也就是跳过所有已经存在于DST，并且文件时间晚于要备份的文件。(不覆盖更新的文件)
-l, --links 保留软链结
-L, --copy-links 想对待常规文件一样处理软链结
--copy-unsafe-links 仅仅拷贝指向SRC路径目录树以外的链结
--safe-links 忽略指向SRC路径目录树以外的链结
-H, --hard-links 保留硬链结
-p, --perms 保持文件权限
-o, --owner 保持文件属主信息
-g, --group 保持文件属组信息
-D, --devices 保持设备文件信息
-t, --times 保持文件时间信息
-S, --sparse 对稀疏文件进行特殊处理以节省DST的空间
-n, --dry-run现实哪些文件将被传输
-W, --whole-file 拷贝文件，不进行增量检测
-x, --one-file-system 不要跨越文件系统边界
-B, --block-size=SIZE 检验算法使用的块尺寸，默认是700字节
-e, --rsh=COMMAND 指定使用rsh、ssh方式进行数据同步
--rsync-path=PATH 指定远程服务器上的rsync命令所在路径信息
-C, --cvs-exclude 使用和CVS一样的方法自动忽略文件，用来排除那些不希望传输的文件
--existing 仅仅更新那些已经存在于DST的文件，而不备份那些新创建的文件
--delete 删除那些DST中SRC没有的文件
--delete-excluded 同样删除接收端那些被该选项指定排除的文件
--delete-after 传输结束以后再删除
--ignore-errors 及时出现IO错误也进行删除
--max-delete=NUM 最多删除NUM个文件
--partial 保留那些因故没有完全传输的文件，以是加快随后的再次传输
--force 强制删除目录，即使不为空
--numeric-ids 不将数字的用户和组ID匹配为用户名和组名
--timeout=TIME IP超时时间，单位为秒
-I, --ignore-times 不跳过那些有同样的时间和长度的文件
--size-only 当决定是否要备份文件时，仅仅察看文件大小而不考虑文件时间
--modify-window=NUM 决定文件是否时间相同时使用的时间戳窗口，默认为0
-T --temp-dir=DIR 在DIR中创建临时文件
--compare-dest=DIR 同样比较DIR中的文件来决定是否需要备份
-P 等同于 --partial
--progress 显示备份过程
-z, --compress 对备份的文件在传输时进行压缩处理
--exclude=PATTERN 指定排除不需要传输的文件模式
--include=PATTERN 指定不排除而需要传输的文件模式
--exclude-from=FILE 排除FILE中指定模式的文件
--include-from=FILE 不排除FILE指定模式匹配的文件
--version 打印版本信息
--address 绑定到特定的地址
--config=FILE 指定其他的配置文件，不使用默认的rsyncd.conf文件
--port=PORT 指定其他的rsync服务端口
--blocking-io 对远程shell使用阻塞IO
-stats 给出某些文件的传输状态
--progress 在传输时现实传输过程
--log-format=formAT 指定日志文件格式
--password-file=FILE 从FILE中得到密码
--bwlimit=KBPS 限制I/O带宽，KBytes per second
-h, --help 显示帮助信息
```
### 10.34.44.117上安装inotify，实现实时同步。
**①安装inotify。**
```
yum install -y make gcc gcc-c++
 wget https://raw.githubusercontent.com/wangchaoforever/peizhiwenjian/master/rsync/inotify-tools-3.14.tar.gz
tar -zxvf inotify-tools-3.14.tar.gz 
cd inotify-tools-3.14
 ./configure --prefix=/usr/local/inotify
 make && make install
```
**②修改inotify默认参数（inotify默认内核参数值太小)**
vim /etc/sysctl.conf
```
fs.inotify.max_user_watches = 26214400
fs.file-max = 1020000
net.ipv4.neigh.default.gc_stale_time = 120
net.ipv4.conf.all.rp_filter = 0
net.ipv4.conf.default.rp_filter = 0
net.ipv4.conf.default.arp_announce = 2
net.ipv4.conf.lo.arp_announce = 2
net.ipv4.conf.all.arp_announce = 2
net.ipv4.tcp_max_tw_buckets = 50000
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_tw_recycle = 1
net.ipv4.tcp_timestamps = 1
net.ipv4.tcp_fin_timeout = 10

net.ipv4.tcp_max_syn_backlog = 1024
net.ipv4.tcp_synack_retries = 2
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1
net.ipv6.conf.eth0.disable_ipv6 = 1
kernel.sysrq = 1
net.ipv4.icmp_echo_ignore_all = 0
fs.inotify.max_queued_events = 99999999
fs.inotify.max_user_instances = 65535
```
sysctl -p   #立即生效
③使用rsync+inotify脚本实时同步图片。
```
#!/bin/bash

SRCDIR=/home/fastdfs/
USER=root
REMOTEIP=10.34.44.224
DESTDIR=fastdfs
hulue_file1=/home/fastdfs/tracker/data/storage_servers_new.dat
hulue_file2=/home/fastdfs/tracker/data/storage_sync_timestamp.dat
hulue_file3=/home/fastdfs/storage/data/.data_init_flag
/usr/local/inotify/bin/inotifywait -mrq --timefmt '%d/%m/%y %H:%M' --format '%T %w%f%e' -e close_write,modify,delete,create,attrib,move $SRCDIR | while read file
do
/usr/bin/rsync -vzrtopg  --delete --progress --bwlimit=3000 --exclude-from=$hulue_file1 --exclude-from=$hulue_file2 --exclude-from=$hulue_file3 --password-file=/etc/rsyncd.secrets  $SRCDIR $USER@$REMOTEIP::$DESTDIR
echo " ${file} was rsynced" >> /tmp/rsync.log 2>&1
done
```
**④启动同步脚本，放在后台执行**

`nohup sh rsync_fastdfs.sh &`

**评估结果：**
由于服务器都在内网传输，交换机是千兆口，也为了不影响业务正常运行，进行了传输限制最大3M/s，整体传输速度还是可以的，但是经过测试实时同步大概需要五秒左右等待时间。基于以上结果，后期还需找更好的实时同步工具，以及有待于观察。









