title: 部署fastdfs集群
date: '2019-05-12 11:48:34'
updated: '2019-05-12 11:48:34'
tags: [fastdfs]
permalink: /articles/2019/05/12/1557632914446.html
---
一、写在前面的话：
①如若需要部署单机版，请看此篇文章，脚本一键安装部署完毕。http://106.12.19.146/articles/2019/04/26/1556268302662.html
②部署环境
centos7.6x2
③服务器规划
**跟踪服务器**  
跟踪服务器1【主机】（Tracker Server）：10.34.44.117 
跟踪服务器2【备机】（Tracker Server）：10.34.44.118
**group1存储服务器**  
存储服务器1（Storage Server）：10.34.44.117
存储服务器2（Storage Server）：10.34.44.118
服务器有限，就使用两台进行集群方式，这就意味着两台机器部署的服务都相同，最后使用nginx做代理。
![QQ浏览器截图20190512104659.png](https://img.hacpai.com/file/2019/05/QQ浏览器截图20190512104659-cadf730f.png)
#所有的安装包都放在了/root/software下面

### 二、具体步骤（两台步骤一样）
#### （1）安装依赖环境以及关闭防火墙和selinux
```
yum install make cmake gcc gcc-c++
systemctl stop firewalld && systemctl disable firewalld && setenforce 0
```
#### (2)安装libfastcommon
```
wget https://github.com/happyfish100/libfastcommon/archive/V1.0.39.tar.gz
tar -zxvf libfastcommon-1.0.39.tar.gz
cd libfastcommon-1.0.39/
./make.sh
./make.sh install
ln -s /usr/lib64/libfastcommon.so /usr/local/lib/libfastcommon.so
ln -s /usr/lib64/libfastcommon.so /usr/lib/libfastcommon.so
ln -s /usr/lib64/libfdfsclient.so /usr/local/lib/libfdfsclient.so
ln -s /usr/lib64/libfdfsclient.so /usr/lib/libfdfsclient.so
```
#### （3）安装fasdfs
```
wget https://github.com/happyfish100/fastdfs/archive/V5.11.tar.gz
tar -zxvf fastdfs-5.11.tar.gz
cd fastdfs-5.11/
./make.sh
./make.sh install
#配置文件准备
cp /etc/fdfs/tracker.conf.sample /etc/fdfs/tracker.conf #tracker节点
cp /etc/fdfs/storage.conf.sample /etc/fdfs/storage.conf #storage节点
cp /etc/fdfs/client.conf.sample /etc/fdfs/client.conf #客户端文件，测试用
cp /opt/fastdfs/fastdfs-5.11/conf/http.conf /etc/fdfs/ #供nginx访问使用
cp /opt/fastdfs/fastdfs-5.11/conf/mime.types /etc/fdfs/ #供nginx访问使用
```
#### （4）配置tracker配置文件
```
vim /etc/fdfs/tracker.conf
#需要修改的内容如下
port=22122 # tracker服务器端口（默认22122,一般不修改）
base_path=/home/fastdfs/tracker # 存储日志和数据的根目录
#创建目录
mkdir -p /home/fastdfs/tracker >>/dev/null
#启动tracker
fdfs_trackerd /etc/fdfs/tracker.conf restart
#查看端口是否监听22122
ss -ntlp | grep 22122
iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport 22122 -j ACCEPT
echo "/usr/bin/fdfs_trackerd /etc/fdfs/tracker.conf restart" >> /etc/rc.local
```
#### (5)修改strorage配置文件
```
vim /etc/fdfs/storage.conf
#需要修改的内容如下
port=23000 # storage服务端口（默认23000,一般不修改）
base_path=/home/fastdfs/storage # 数据和日志文件存储根目录
store_path0=/home/fastdfs/storage # 第一个存储目录
tracker_server=10.34.44.117:22122 # tracker服务器IP和端口
tracker_server=10.34.44.118:22122 # tracker服务器IP和端口
http.server_port=8888 # http访问文件的端口(默认8888,看情况修改,和nginx中保持一致)
```
#创建storage目录
mkdir /home/fastdfs/storage -p
#启动storage 
fdfs_storaged /etc/fdfs/storage.conf restart
ss -ntlp | grep 23000
#如果启动失败，请确认配置文件路径以及查看日志解决。
#查看集群状态
$ fdfs_monitor /etc/fdfs/storage.conf list
![1.png](https://img.hacpai.com/file/2019/05/1-1640b35a.png)
---
![2.png](https://img.hacpai.com/file/2019/05/2-6224e50b.png)
#### （6）client配置
```
vim /etc/fdfs/client.conf
#需要修改的内容如下
base_path=/home/fastdfs/tracker
tracker_server=10.34.44.117:22122 # tracker服务器IP和端口
tracker_server=10.34.44.118:22122 # tracker服务器IP和端口
```
#保存后测试
fdfs_upload_file /etc/fdfs/client.conf 111.png 
![3.png](https://img.hacpai.com/file/2019/05/3-99d3c9f4.png)
---
![4.png](https://img.hacpai.com/file/2019/05/4-61a295d1.png)
#两个storage都有相同的文件，此时已经成功。
#### （7）安装nginx和fastdfs-nginx-module
①下载nginx module
```
cd /root/software
wget https://github.com/happyfish100/fastdfs-nginx-module/archive/V1.20.tar.gz
tar zxvf V1.20.tar.gz
cp /opt/fastdfs/fastdfs-nginx-module-1.20/src/mod_fastdfs.conf /etc/fdfs
#### 修改 fastdfs-nginx-module 的 config 配置文件
cd fastdfs-nginx-module/src
vim config
将
CORE_INCS="$CORE_INCS /usr/local/include/fastdfs /usr/local/include/fastcommon/"
修改为
CORE_INCS="$CORE_INCS /usr/include/fastdfs /usr/include/fastcommon/"
```
②下载并编译安装nginx
```
yum -y install libtool pcre pcre-devel zlib zlib-devel openssl openssl-devel
wget http://nginx.org/download/nginx-1.4.7.tar.gz
wget http://122.114.164.162:10004/pcre-8.36.tar.gz
tar zxvf nginx-1.4.7.tar.gz
tar zxvf pcre-8.36.tar.gz
cd /root/src/nginx-1.4.7
./configure --prefix=/usr/local/nginx --add-module=/root/software/fastdfs-nginx-module/src --with-pcre=/root/software/pcre-8.36
sleep 5
make && make install
```
#查看nginx的版本以及安装的模块
![5.png](https://img.hacpai.com/file/2019/05/5-5aa72ff3.png)

③### 复制 fastdfs-nginx-module 源码中的配置文件到 /etc/fdfs 目录，并修改

```
cp /root/software/fastdfs-nginx-module/src/mod_fastdfs.conf /etc/fdfs/
vi /etc/fdfs/mod_fastdfs.conf 
```

修改以下配置：

```
connect_timeout=10
base_path=/home/fastdfs/tracker
tracker_server=10.34.44.117:22122 # tracker服务器IP和端口
tracker_server=10.34.44.118:22122 #tracker服务器IP2和端口
group_name=group1                 #当前服务器的group名
url_have_group_name=true #url中包含group名称
store_path0=/home/fastdfs/storage #存储路径
```
#测试，刚才我们上传的一张图片。
![7.png](https://img.hacpai.com/file/2019/05/7-7ec069c7.png)
---
![6.png](https://img.hacpai.com/file/2019/05/6-472a086a.png)
#至此fasfdfs集群已经OK了。
接下来我们在10.34.44.117上面再安装个nginx，做反向代理。
```
yum install nginx -y
vim /etc/nginx/nginx.conf
upstream fdfs_group1 {

        server 10.34.44.117:8888 weight=1 max_fails=2 fail_timeout=30s;
        server 10.34.44.118:8888 weight=1 max_fails=2 fail_timeout=30s;
    }
location /group1/M00 {

            proxy_pass http://fdfs_group1;
        }
```
再访问下刚才的图片
![8.png](https://img.hacpai.com/file/2019/05/8-84eca3fb.png)
#后期根据实际情况，可以把tracker、storage分开部署，以及反向代理nginx可以做高可用。


