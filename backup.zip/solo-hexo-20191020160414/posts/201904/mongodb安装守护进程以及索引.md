title: mongodb安装、守护进程以及索引
date: '2019-04-26 17:01:38'
updated: '2019-04-30 14:43:14'
tags: [mongodb]
permalink: /articles/2019/04/26/1556269298264.html
---
![](https://img.hacpai.com/bing/20181021.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 1、制作源并安装mongodb数据库

1.  cat<<EOF>/etc/yum.repos.d/mongodb-org.repo
2.  [mongodb-org]
3.  [mongodb-org]
4.  name=MongoDBRepository
5.  baseurl=http://mirrors.aliyun.com/mongodb/yum/redhat/7Server/mongodb-org/3.6/x86_64/
6.  gpgcheck=0
7.  enabled=1
8.  EOF

开始安装：

1.  yum-y makecache fast
2.  yum install-y mongodb-org
3.  systemctl enable mongod#开机自启

#### 2、修改配置文件

1.  sed-i"s/bindIp: 127.0.0.1/bindIp: 0.0.0.0/g"/etc/mongod.conf
2.  systemctl restart mongod

#### 3、新建索引并创建自动删除10天以前数据的计划

##### 1.rawData collections 创建过程

1.  show dbs
2.  usedatacollect
3.  show collections
4.  db.rawData.findOne()
5.  db.rawData.createIndex({"source":1,"time":-1},{name:"rawData_created_timescidx"},{expireAfterSeconds:3600*10},{background:true})
6.  db.rawData.getIndexes()

##### 2.exceptionData collections 创建过程

1.  show dbs
2.  usedatacollect
3.  show collections
4.  db.exceptionData.findOne()
5.  db.exceptionData.createIndex({"source":1,"time":-1},{name:"excdt_created_timescidx"},{expireAfterSeconds:3600*10},{background:true})
6.  db.exceptionData.getIndexes()

注意：以上方法虽然为后台运行，但尽量不要在数据量比较大的mongodb数据库中执行。

##### 3.查看执行计划的执行过程

1.  db.rawData.find({source:'ht-84'}).explain('executionStats')

#### 4、mongodb守护进程脚本

1.  cat<<EOF>/usr/bin/shouhu.sh
2.  #!/bin/sh
3.  #添加本地路径如果有
4.  whiletrue;do
5.  #启动一个循环，定时检查进程是否存在
6.  server=`ps aux | grep mongod | grep -v grep`
7.  if[!"$server"];then
8.  #如果不存在就重新启动
9.  systemctl restart mongod&
10.  #启动后沉睡5s
11.  sleep5
12.  fi
13.  #每次循环沉睡5s
14.  sleep5
15.  done
16.  EOF
17.  chmod a+x/usr/bin/shouhu.sh
18.  sh/usr/bin/shouhu.sh2>&1&